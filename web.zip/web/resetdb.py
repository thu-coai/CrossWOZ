from data_labelling.utils import resetdb

if __name__ == '__main__':
    resetdb()
