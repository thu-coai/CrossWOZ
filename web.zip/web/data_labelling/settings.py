from datetime import timedelta

SECRET_KEY = 'SECRET_KEY_FOR_FLASK_SESSION'
PERMANENT_SESSION_LIFETIME = timedelta(days=30)

# FLASK_ADMIN_SWATCH = 'united'
